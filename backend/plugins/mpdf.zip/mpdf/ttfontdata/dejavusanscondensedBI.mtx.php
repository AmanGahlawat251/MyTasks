<?php
$name='DejaVuSansCondensed-BoldOblique';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 262212,
  'FontBBox' => '[-960 -385 1799 1121]',
  'ItalicAngle' => -11,
  'StemV' => 165,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='/var/www/html/www.yourtelwireless.com/mpdf/ttfonts/DejaVuSansCondensed-BoldOblique.ttf';
$TTCfontID='0';
$originalsize=493756;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusanscondensedBI';
$panose='0 0 2 11 8 6 3 3 4 11 2 4';
$haskerninfo=false;
?>